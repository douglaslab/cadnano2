
"""
__init__.py

Created by Shawn Douglas on 2011-01-23.

"""
